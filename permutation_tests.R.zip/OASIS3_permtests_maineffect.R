# main effect
library(predictmeans)
## Test fixed effects of the interaction
data=read.csv('lme_info.csv') #import data generated from matlab
fm1 <- lmer(F_IC2IC5 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC2IC5 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC2IC6 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC2IC6 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC5IC7 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC5IC7 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC8IC10 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC8IC10 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC2IC15 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC2IC15 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC3IC15 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC3IC15 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC4IC15 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC4IC15 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC5IC15 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC5IC15 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC8IC15 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC8IC15 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC10IC15 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC10IC15 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC13IC16 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC13IC16 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC15IC16 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC15IC16 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC1IC19 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC1IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC2IC19 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC2IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)


fm1 <- lmer(F_IC5IC19 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC5IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC6IC19 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC6IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC8IC19 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC8IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC15IC19 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC15IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(F_IC16IC19 ~ time_in_y+ prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(F_IC16IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)
