library(predictmeans)
data=read.csv('uncorrectedsign_connectivities.csv')
## Test fixed effects of the interaction
fm1 <- lmer(IC2IC5 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC2IC5 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC2IC6 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC2IC6 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC2IC7 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC2IC7 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC1IC8 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC1IC8 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC2IC10 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC2IC10 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC8IC10 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC8IC10 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC2IC11 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC2IC11 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC3IC11 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC3IC11 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC5IC11 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC5IC11 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC8IC12 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC8IC12 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC3IC13 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC3IC13 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC11IC13 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC11IC13 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC6IC16 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC6IC16 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC9IC16 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC9IC16 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC6IC18 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC6IC18 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC13IC18 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC13IC18 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC1IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC1IC19 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC2IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC2IC19 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC6IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC6IC19 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC7IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC7IC19 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC10IC19 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC10IC19 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC6IC21 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC6IC21 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC10IC21 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC10IC21 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC13IC21 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC13IC21 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

fm1 <- lmer(IC14IC21 ~ time_in_y+delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
fm2 <- lmer(IC14IC21 ~ time_in_y*delta + prop_signal + mean_fd + baseline_cdr + baseline_age + sex + time_in_y + (time_in_y|Subs), data=data)
anova(fm1, fm2)
permlmer(fm1, fm2)

